const express = require("express");
const res = require("express/lib/response");
//const { json } = require("express/lib/response");
const sql = require("mysql2");
const app = express();
const body = require("body-parser");
//const { version } = require("npm/lib/npm");
const bcrypt = require("bcryptjs");

let username = null;

const conn = sql.createConnection({
    host: "localhost",
    user: "root",
    password: "admin",
    // change
    database: "project"
});

conn.connect((err) => {
    if (err) {
        console.log("Connection Failed");
    } else {
        console.log("Connection Successful");
    }
});

app.use(express.static("public"));
app.use(body.json());
app.use(body.urlencoded({extended:false}));

//sends main page
app.get("/main", (req, res) => {
    res.sendFile(__dirname + "/public/main.html");
});

//sends account page
app.get("/account", (req, res) => {
    res.sendFile(__dirname + "/public/account.html");
});

// returns user info for account page
app.get("/info", (req, res) => {
    query = "select * from users where username = ?";
        conn.query(query, [username], (err, r) => {
            r.forEach((row) => {
                res.json({success: true, user: username, email: row.email, first: row.firstname, last: row.lastname}).end;
            });
        });
});

//sends login page
app.get("/login", (req, res) => {
    username = null;
    res.sendFile(__dirname + "/public/index.html");
});

// used to let user login
app.post("/login", (req, res) => {
    let name = req.body.username;
    let password = req.body.password;
    let query = `select * from users where username = ?`;

    // checks for admin access and if not checks if user credntials are correct 
    conn.query(query, [name], (err, rows) => {
        if (rows.length === 0) {
            res.json({success: false}).end;
        } else {
            if (rows[0].username === "admin" && rows[0].password === "admin") {
                res.json({success: true}).end;
                username = rows[0].username;
            } else {
                rows.forEach((row) => {
                    query = "select * from users where username = ?"
                    conn.query(query, [name], (err, r) => {
                        if (row.username === name && bcrypt.compareSync(password, row.password)) {
                            username = row.username;
                            res.json({success: true}).end;
                        } else {
                            res.json({success: false}).end;
                        }
                    });
                });
            }
        }
    });
});

// sends registration page
app.get("/register", (req, res) => {
    res.sendFile(__dirname + "/public/register.html");
});

// checks to see if username already exists, if not, then it proceeds to let user register
app.post("/register", (req, res) => {
    let name = req.body.username;
    let password = req.body.password;
    let email = req.body.email;
    let first_name = req.body.first_name;
    let last_name = req.body.last_name;
    let query = "select * from users where username = ?";

    conn.query(query, [name], (err, row) => {
        if (row.length > 0) {
            res.json({success: false});
            res.send();
            return;
        } else {
            let create = "insert into users values (?, ?, ?, ?, ?)";
            conn.query(create, [name, bcrypt.hashSync(password, 10), email, first_name, last_name], (err, res) => {
                if (err) {
                    console.log(err); 
                } else {
                    console.log("Rows: " + res.affectedRows);
                }
            });
            
            username = name;
            res.json({success: true});
            res.send();
            return;
        }
    });
});

app.listen(3000, () => {
    console.log("Started on port 3000...");
});

