let username = document.getElementById("username");
let password = document.getElementById("password");
let submit = document.getElementById("login");


function login(event){
    event.preventDefault();
    let xhr = new XMLHttpRequest;
    xhr.addEventListener("load", responseHandler);
    query=`username=${username.value}&password=${password.value}`;
    url = "/login";
    xhr.responseType = "json";   
    xhr.open("POST", url);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(query);
}

function responseHandler(){
    let status = document.getElementById("status");
    if (this.response.success) {
        //status.hidden = true;
        location.replace("/account");
    } else {
        status.hidden = false;
        password.value = "";
    }
}

submit.addEventListener("click", login);