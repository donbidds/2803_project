let xhr = new XMLHttpRequest;
xhr.addEventListener("load", responseHandler);
url = "/info";
xhr.responseType = "json";   
xhr.open("GET", url);
xhr.send();

function responseHandler(){
    username.innerHTML = "Hello, " + this.response.user;
    first_name.innerHTML = "First Name: " + this.response.first;
    last_name.innerHTML = "Last Name: " + this.response.last;
    email.innerHTML = "Email: " + this.response.email;
}

let logout = document.getElementById("logout");
logout.addEventListener("click", () => {
    location.replace("/login");
});