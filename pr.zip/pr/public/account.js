
function getInfo() {
    let xhr = new XMLHttpRequest;
    xhr.addEventListener("load", responseHandler);
    url = "/info";
    xhr.responseType = "json";   
    xhr.open("GET", url);
    xhr.send(); 
}

function responseHandler(){
    username.innerHTML = "Hello, " + this.response.user;
    first_name.innerHTML = "First Name: " + this.response.first;
    last_name.innerHTML = "Last Name: " + this.response.last;
    email.innerHTML = "Email: " + this.response.email;

    let xhr = new XMLHttpRequest;
    xhr.addEventListener("load", responseHandler2);
    url = "/list";
    xhr.responseType = "json";   
    xhr.open("GET", url);
    xhr.send(); 
}

function responseHandler2() {
    let titles = this.response.titles;
    let posters = this.response.posters;
    console.log(posters);

    if (titles) {
        
        let container = document.getElementById("list");

        let i = 0;
        while (i < titles.length) {
            let flex = document.createElement("div");
            flex.setAttribute("class", "entry");
            flex.setAttribute("id", titles[i]);

            let poster = document.createElement("img");
            poster.setAttribute("src", posters[i]);
            poster.setAttribute("class", "poster");

            let name = document.createElement("p");
            name.setAttribute("class", titles[i]);
            name.innerHTML = titles[i];

            let button = document.createElement("button");
            button.setAttribute("class", "delete");
            button.setAttribute("id", titles[i]);
            button.innerHTML = "X";

            console.log(button.id);

            button.addEventListener("click", (event) => {
                event.preventDefault();
                let xhr = new XMLHttpRequest;
                xhr.addEventListener("load", responseHandler3);
                query=`title=${button.id}`;
                url = "/list";
                xhr.responseType = "json";   
                xhr.open("POST", url);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.send(query);

                let remove = document.getElementById(button.id);
                container.removeChild(remove);
            });

            flex.appendChild(poster);
            flex.appendChild(name);
            flex.appendChild(button);
            container.appendChild(flex);

            i++;
        }

    }
}

function responseHandler3() {
}

let logout = document.getElementById("logout");
logout.addEventListener("click", () => {
    location.replace("/login");
});

window.addEventListener("load", (event) => {
    getInfo();
});

