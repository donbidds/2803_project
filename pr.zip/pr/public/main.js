let ids = [];
function getTitles() {
    console.log("Hello");
    let xhr = new XMLHttpRequest;
    xhr.addEventListener("load", responseHandler);
    url = "https://api.themoviedb.org/3/trending/all/day?api_key=2a8032466537d924e29b928a1af23e6f";
    xhr.responseType = "json";   
    xhr.open("GET", url);
    xhr.send();
}

function responseHandler(){
    var items = JSON.parse(JSON.stringify(this.response));
    
    console.log(items.results[0]);

    let i = 0;
    let parent = document.getElementById("movies");
    while (i <= 14) {
        let movie = document.createElement(`div`);
        movie.setAttribute("id", `movie${i}`);
        
        let image = document.createElement("img");
        image.setAttribute("src", `https://image.tmdb.org/t/p/w500${items.results[i].poster_path}`);

        let name = document.createElement("p");
        let rating = document.createElement("p");
        let date = document.createElement("p");
        let description = document.createElement("p");

        if (items.results[i].media_type === "movie") {
            name.innerHTML = items.results[i].title;
            date.innerHTML = `Release Date: ${items.results[i].release_date}`;
        } else {
            name.innerHTML = items.results[i].name;
            date.innerHTML = `First Air Date: ${items.results[i].first_air_date}`;
        }
        ids[i] = items.results[i].id;
        movie.setAttribute("id", `${items.results[i].id}`);

        name.setAttribute("class", "title");

        if (items.results[i].vote_average === 0) {
            rating.innerHTML = `Rating: N/A`;
        } else {
            rating.innerHTML = `Rating: ${items.results[i].vote_average}`;
        }

        description.innerHTML = items.results[i].overview;

        parent.appendChild(movie);

        movie.appendChild(image);
        movie.appendChild(name);
        movie.appendChild(rating);
        /** 
         * movie.appendChild(date);
           movie.appendChild(description); 
         * 
        */
        
        i++;
    }

    ids.forEach((id) => {
        if (id) {
            let add = document.getElementById(id);
            let image = add.querySelector("img");
            image.addEventListener("click", (event) => {
                let i = 0;

                while (items.results[i]) {
                    if (items.results[i].id === id) {
                        var type = items.results[i].media_type;
                    }
                    i++;
                }

                console.log("id: " + id);
                console.log("type: " + type);
                
                event.preventDefault();
                let xhr = new XMLHttpRequest;
                xhr.addEventListener("load", (event) => {
                    console.log("Done");
                });
                query=`id=${id}&type=${type}`;
                url = "/type";
                xhr.responseType = "json";   
                xhr.open("POST", url);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.send(query);
                window.location.replace("/overview");
            });
        }
    });
}

window.addEventListener("load", (event) => {
    getTitles();
})

