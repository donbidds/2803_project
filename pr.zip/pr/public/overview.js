let movie = null;
let type = true;
let id = 0;
let button = null;
let check_status = null;
let poster = null;


function getPage() {
    let xhr = new XMLHttpRequest;
    xhr.addEventListener("load", responseHandler);
    url = "/focus";
    xhr.responseType = "json";   
    xhr.open("GET", url);
    xhr.send();
}

function responseHandler() {
    id = this.response.id;
    type = this.response.type;
    console.log("THIS: " + id + ", " + type);
    
    
    let xhr = new XMLHttpRequest;
    xhr.addEventListener("load", responseHandler2);

    if (!type) {
        url = `https://api.themoviedb.org/3/tv/${id}?api_key=2a8032466537d924e29b928a1af23e6f&language=en-US`;
    } else {
        url = `https://api.themoviedb.org/3/movie/${id}?api_key=2a8032466537d924e29b928a1af23e6f&language=en-US`;
    }
    xhr.responseType = "json";   
    xhr.open("GET", url);
    xhr.send();
}

function responseHandler2(){
    let items = JSON.parse(JSON.stringify(this.response));
    console.log(items);

    let parent = document.getElementById("result");


    let movie = document.createElement(`div`);
    movie.setAttribute("id", `image`);
    let image = document.createElement("img");
    image.setAttribute("src", `https://image.tmdb.org/t/p/w500${items.poster_path}`);
    poster = `https://image.tmdb.org/t/p/w500${items.poster_path}`;
    parent.appendChild(movie);
    movie.appendChild(image);

    let desc = document.createElement(`div`);
    desc.setAttribute("id", `description`);
    let name = document.createElement("p");
    let rating = document.createElement("p");
    let date = document.createElement("p");
    let description = document.createElement("p");

    button = document.createElement("button");
    button.setAttribute("id", "add");
    button.innerHTML = "Add to Watchlist" 

    if (type) {
        name.innerHTML = items.original_title;
        date.innerHTML = `Release Date: ${items.release_date}`;
    } else {
        name.innerHTML = items.name;
        date.innerHTML = `First Air Date: ${items.first_air_date}`;
    }
    date.setAttribute("class", "desc");

    name.setAttribute("id", "title");

    check_status = document.createElement("p");
    check_status.innerHTML = "Already on Watchlist"
    check_status.hidden = true;
    check_status.setAttribute("id", "status");

    button.addEventListener("click", (event) => {
        event.preventDefault();
        let xhr = new XMLHttpRequest;
        xhr.addEventListener("load", responseHandler3);
        query=`name=${name.innerHTML}&poster=${poster}`;
        url = "/add";
        xhr.responseType = "json";   
        xhr.open("POST", url);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(query);
        //window.location.replace("/overview");
    });

    if (items.vote_average === 0) {
        rating.innerHTML = `Rating: N/A`;
    } else {
        rating.innerHTML = `Rating: ${items.vote_average}`;
    }
    rating.setAttribute("class", "desc");

    description.innerHTML = items.overview;
    description.setAttribute("class", "desc");
    description.setAttribute("id", "descrip");

    desc.appendChild(name);
    desc.appendChild(rating);
    desc.appendChild(date);
    desc.appendChild(description);
    desc.appendChild(button);
    desc.appendChild(check_status);
    parent.appendChild(desc);
}

let searc = document.getElementById("title");
let submit = document.getElementById("submit");

window.addEventListener("load", (event) => {
    getPage();
});

function responseHandler3(){
    let status = document.getElementById("status");
    console.log(this.response.success);
    if (this.response.success === true) {
        button.disabled = true;
        check_status.innerHTML = "Added to Watchlist";
    } else {
        button.disabled = true;
        check_status.innerHTML = "Already on Watchlist";
    }

    check_status.hidden = false;
}

