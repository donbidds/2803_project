let username = document.getElementById("username");
let password = document.getElementById("password");
let password2 = document.getElementById("password2");
let email = document.getElementById("email");
let first_name = document.getElementById("first_name");
let last_name = document.getElementById("last_name");
let submit = document.getElementById("submit");


function make(event){
    if (username.value === "" || password.value === "" || password.value === "" || email.value === "" 
        || first_name.value === "" || last_name.value === "") {
        let message = document.getElementById("status");
        message.innerHTML = "Some field(s) are empty";
        message.hidden = false;
    } else if (password.value != password2.value) {
        let message = document.getElementById("status");
        message.innerHTML = "Passwords don't match";
        message.hidden = false;
    } else {
        event.preventDefault();
         let xhr = new XMLHttpRequest
        xhr.addEventListener("load", responseHandler)

        query=`username=${username.value}&password=${password.value}&email=${email.value}&first_name=${first_name.value}&last_name=${last_name.value}`;
        url = "/register";
        xhr.responseType = "json";  
    
        xhr.open("POST", url);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(query);
    }
}

function responseHandler(){
    //location.replace("/login");
    let status = document.getElementById("status");
    if (this.response.success) {
        location.replace("/account");
    } else {
        let message = document.getElementById("status");
        message.innerHTML = "Username already exists";
        message.hidden = false;
    }
}

submit.addEventListener("click", make);

password2.addEventListener("input", () => {
    let message = document.getElementById("status");
    if (password.value != password2.value) {
        message.innerHTML = "Passwords do not match";
        message.hidden = false;
    } else {
        message.hidden = true;
    }
});

username.addEventListener("input", (event) => {
    event.preventDefault();
        let xhr = new XMLHttpRequest
        xhr.addEventListener("load", responseHandler2)

        query=`username=${username.value}`;
        url = "/check";
        xhr.responseType = "json";  
    
        xhr.open("POST", url);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(query);
});

function responseHandler2(){
    let message = document.getElementById("status");
    if (!this.response.success) {
        message.innerHTML = "Username already exists";
        message.hidden = false;
    } else {
        message.hidden = true;
    }
}

