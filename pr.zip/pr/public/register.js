let username = document.getElementById("username");
let password = document.getElementById("password");
let password2 = document.getElementById("password2");
let email = document.getElementById("email");
let first_name = document.getElementById("first_name");
let last_name = document.getElementById("last_name");
let submit = document.getElementById("submit");


function make(event){
    event.preventDefault()
    let xhr = new XMLHttpRequest
    xhr.addEventListener("load", responseHandler)
    query=`username=${username.value}&password=${password.value}&email=${email.value}&first_name=${first_name.value}&last_name=${last_name.value}`;
    url = "/register"
    xhr.responseType = "json";   
    xhr.open("POST", url)
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
    xhr.send(query)
}

function responseHandler(){
    //location.replace("/login");
    let status = document.getElementById("status");
    if (this.response.success) {
        location.replace("/account");
    } else {
        let message = document.getElementById("status");
        message.hidden = false;
    }
}

submit.addEventListener("click", make);